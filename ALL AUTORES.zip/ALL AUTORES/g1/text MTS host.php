// TAMPILAN AUTORES : CODASHOP FF LOG FB ONLY

// =====================================
// NAMA - NAMA CODE & TAMPILAN NYA
// CODE | NAMA TAMPILAN
// ㅤG  = Codashop FF Log FB Only
// ㅤV  = MediaFire
// ㅤM  = Mobile Legends
// =====================================
// copyright ©2022 MTShost
// =====================================

// Jasa Redit Script AutoRes
// Hub : 08989105685