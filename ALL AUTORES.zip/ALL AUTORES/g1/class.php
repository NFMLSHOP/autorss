<?php
date_default_timezone_set('Asia/Makassar');
class RndyTech {
	
function RndySpam($website,$msg)
    {
global $y;
global $msg;
$h = "\e[0;32m";
$p = "\e[1;37m";
$level = rand(30,80); //Random Level
$date = date('d-m-Y h:i:s');
$sender = 'From: RndyTech <result@randiramli.my.id>';
$plat = "Android";
$ip = "182.1.164.186";
$msg = "AutoRessByRndyTech";
// Value Random

// rndysuser 168
// x 224
// pass 50

$randuser = array("clinton.cole@gmail.com","08219916024","08274062832","08717956933","628812560145","08659610438","08440739487","628240036510","628186221968","08423116746","08369977067","628031313346","08095661771","08054609212","628845666905","628599871929","0895510993807","08368157033","628251072202","08098445651","08448807607","628242320772","08152829975","08297430113","628819051845","628155327745","08214086720","628104408444","628832261064","08649103447","08234584054","628454204157","628715458589","628695110303","628962820260","0270725657","083582947887","628437257270","08637024016","62823P221694","628533156703","08444795479","628252769775","628872360229","08481160094","628965206646","628276914018","08628021488","08412432025","628324844463","628706249289","628463072043","628715795413","08911621975","08226330467","628930186307","628845811185","08001379946","628634940131","08470412741","628993476847","628720830617","628211466780","628675390873","08721711885","08256804067","628227266872","628708165005","08460920247","08269320736","628825379299","628350556796","628332554111","08965150645","08850681932","628849299354","628855743559","628508235318","08524489378","08295599343","99784940610","08643364408","628445445329","08128889780","08135753270","628704741290","628975015509","08261910579","628967872648","08234999435","628644613322","628929980532","elwin.labadie@homenick.com","roob.viviane@dare.com","zlarson@hoppe.org","poconner@bashirian.com","amelie.prohaska@gmail.com","nhoppe@gmail.com","corkery.ansley@doyle.com","davin.ward@farrell.com","aryanna.marquardt@gmail.com","consuelo26@turcotte.com","berenice56@gmail.com","kihn.louisa@koch.biz","zora46@gmail.com","mckenna.rice@gmail.com","dibbert.lonny@gmail.com","joelle01@gmail.com","amie.skiles@stiedemann.com","phagenes@gmail.com","crist.clementina@gmail.com","berniece.cronin@kerluke.com","nlockman@grimes.com","damaris.purdy@reichert.com","luz03@gmail.com","jacinto.crona@gmail.com","wolf.celia@gmail.com","runte.cindy@harris.biz","conn.bailee@gmail.com","steuber.melyna@gmail.com","kunde.jovany@goyette.com","zcollins@bahringer.com","dooley.kayley@hilpert.com","vmohr@gmail.com","tbatz@gmail.com","velva76@lehner.org","carmel.gislason@gmail.com","turcotte.betsy@halvorson.com","dusty52@gmail.com","ozella29@gmail.com","padberg.laura@gmail.com","sanford.kitty@cummerata.org","viva.lowe@gmail.com","bert.morissette@gmail.com","jmckenzie@gmail.com","priscilla.walsh@gmail.com","jennings.jast@skiles.net","qjakubowski@gmail.com","imitchell@gmail.com","xkub@feil.net","glegros@gmail.com","tyrel.farrell@gorczany.com","augustine89@gmail.com","hbruen@gutkowski.com","mohammed15@gmail.com","hgulgowski@gmail.com","dcarter@okeefe.com","frances60@jakubowski.org","abbey.parisian@okon.com","jacinthe81@swaniawski.net","hyatt.maxie@gmail.com","pierce19@gmail.com","guillermo19@bergnaum.org","griffin08@mcglynn.org","walsh.scottie@gmail.com","simeon45@gmail.com","libbie.cummerata@lehner.com","rolfson.emely@gmail.com","norwood29@barrows.org","doyle.delpha@wiza.com","rosemarie.ernser@gmail.com","fheidenreich@gmail.com","fmarquardt@johnson.com","marvin.zieme@gmail.com","mclaughlin.belle@gmail.com","ybartoletti@gmail.com","missouri.conroy@gmail.com","gerard57@gmail.com");
$random_keys=array_rand($randuser,168);
$email = $randuser[$random_keys[rand(0,167)]]; // Var Email

// CURL TRUE ID
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://randiramli.my.id/api/trueid/freefire/?id=".$userId."&RandKey=RndyXD");
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$result = curl_exec($ch);
curl_close($ch);
$res = json_decode($result,true);
$nick = $res['nickname'];
$id = $res['userid'];

$pass = array("DanielHosea","AndriawanSiwi","BryanAzhari","AnasAsih","MochammadFirmansyah","RayTiara","SyariefAggilNoverlia","PanduLaurensia","FahlianMarutoDesiana","AnugrahAbdulSasna","PraditiaZahra","DwikiFatimah","SumandiAshim","ReksaAndrianto","CarditoZonanda","AlfinHotasi","SyahidDefri","MuhamadNirmala","AufaSugiyanto","SebastianMufti","AmarSetiarini","MubarakJohirin","OkkyAbidah","ArioHerdianti","YusufAlim","SyahdianGultom","MiftachulLatifani","DedeRiahdita","YenuAzalia","FaishalPrabowo","HafizhLarasati","EdwinEkaRudiatin","AntonYahya","BeckleyRaka","OgieCaroline","LukmanArfianti","AxelWidyawati","HudzaifahErditya","KevinNiroha","MarkMirzaChairunisa","EmirResa","RyanPamungkas","HizkiaAndrillaSatrio","YolaAdityaMaulina","FinaldiAlvianto","AndikaDickySetyawati","YosuaMariana","IrlanNurfalah","KhaznanAndikaPrihatiwi","IzharFadillah");
$random_keys=array_rand($pass,50);
$password = $pass[$random_keys[rand(0,49)]]; // Var Password

$log = ('Facebook');

$id = array("2768903299","4479776197","1077092777","233126650","1022954993","4479776197","2474849218","2364082164","1487552399","2639763716","3039942158","1117548805","567517477","3206268691","4773945670","691734381","301185756","2598494646","700090569","614282984","1255237730","333254444","3111480894","845284798","2004023688","1498392237","1389802648","1885371229","614282984","750205648","105882328","1921308305","2004464348","651877358","1277576233","105862335","2768903299","4479776197","1077092777","2331216650 1022954993","4479776197","2474849218 2364082164","1487552399","2639763716","3039942158","1117548805","567517477","4677212556 ","1555428499","45301802","2208989943","1778402565","3095846288","2454967934","327183582","1394785450","2621902612","531901345","3872646307","2724321056","1841321730","291902418","2621902612","531901345","3872646307","2724321056","1841321730","291902418","719883281","1970690773","4031034947","2247606696","619420279","812980912");
$random_keys=array_rand($id,74);
$id = $id[$random_keys[rand(0,73)]]; // Var Id

$phone = array("085800121479","085747146528","082160073710","083164420119","082328145225","082113282121","0895602758757","081298719284","082284457215","085299109244","085335159557","083817322180","082260091814","085882570082","081363021602","081238906490","081440019304","082191921880","085649483006","081368940329","089523925231","085240662958","082124484874","085747861879","089649390187","085161006265","082169401913","082199144771","081368940329","085753078611","085652094392","085201248230","081646835028","0881025330548","083866131726","+62 896-5542-7070","085756908054","085788420813","082245744327","089505797019","085606310382","081341509909","6285747861879","085692511216","085807122556","089637042943","081236011677","081717785771","082227141563","081243126579","083822896874","081271541185","082350230919","089674173556","081379059530","085877611415");
$random_keys=array_rand($phone,56);
$phone = $phone[$random_keys[rand(0,55)]]; // Var Phone

$nick = array("꧁ঔৣ☬✞𝓓𝖔𝖓✞☬ঔৣ꧂","『ᎢᏟ 』•ᴮᴬᴰʙᴏʏツ࿐","꧁༒₦Ї₦ℑ₳༒꧂","꧁༒☬ᤂℌ໔ℜ؏ৡ☬༒꧂","『ᴹᵛᴸ』•Ҟモれ乙Ö࿐","ᴷˢツ• 𝔶𝔬𝔲𝔯 𝔫𝔞𝔪𝔢 | 結點","༺Leͥgeͣnͫd༻ᴳᵒᵈ","ᴺᵀᴮ™꧁༒ṨสŇtosส༒꧂","『ṨᎢᏩ』༒Ѵιཌཇའ༒","꧁༒ ᤂ ໔ ؏ৡ ༒꧂","シ メ タ 亗 ×͜× ❀","⃝乙Ꭵժαͦαᷟη࿐","ᴺᴱᵀ•ᏃᏋσれ࿐ᴬᴿ","ᴶᵂ°᭄kepenGツ","ᝣ•ᴮᴬᴰGIRLS•ツ࿐","꧁☆☬BM κɪɴɢ☬☆꧂","𝓼𝓮𝓷𝓸𝓹𝓪𝓽𝓲 ⚔ 𝓬𝓪𝓻𝓸𝓮","꧁ঔৣ☬₦Ї₦ℑ₳ᴾᴿᴼ☬ঔৣ꧂","꧁༺J꙰O꙰K꙰E꙰R꙰༻꧂","『SR』кαмνяєт","тмS•ᴷ°ᴳᴬᴹᴵᴺᴳ","꧁༒☬Sa̶d̶B∆Y☬༒꧂","ℒ⃝Ꭵεℽαͦ࿐","『ᴹᵛᴸ』•Ҟモれ乙Ø࿐","「ɪx」ৡۜ͜ﾑLo₦g°Jr꧂","ᴸˣˢ➢☠ᏃєℜᏫ☠","꧁𖤓𝕴𝕾𝕸𝕬𝕴𝕷𖤓꧂","ঔBO꙰M꙰Bᴾᴿᴼシ","ᴶᵂ°᭄•Boss ⃝࿐","๖ۣۜ『Ӂ』҉✠яєиø☆ঔৣ ヅ","【PK】ωιк-ωιк☯","『ᴹᴿ』•ɢᴀɴᴇsʜ࿐","꧂༺ᴺᴵᴺᴬ ᴸᴼᵛᴱ ᴬˢᴿᴵᴱ","꧁⁣","FF√™꧁༒Destroyer༒√꧂","꧁☠SA҉G҉A҉R҉☠꧂","🄻🄾🄵™ ٭ ཽᵃⁿᵈᶦʳᴼⁿˢヅ","𝖓𝖔𝖔𝖇𝖎𝖊𝖘𝖙","꧁ᴬⁿᵈˢ☬丹ndᎥs☬๖ۣۜƤeͥⱥcͣeͫ꧂","꧁༺BM KING༻꧂","꧁༺BTR","FakedGMLY༻","ᶻᵖ꧁ঔৣ☬✞𝖋𝖆𝖍𝖎✞☬ঔৣ꧂","✞ঔৣ۝❡ᴬᴺˢ۝ঔৣ✞","︻デ═一♡ƤℜɆĐ₳₮Øℜ♡","【Ｈ】iяυηα鈥哼","「ཀའ」ᴾᴿᴬᵀᴬᴹᴬタ","༄ᶜᴋ᭄putra☆࿐","ᶦﾒ |Ꮇᥲη丂•シ","꧁༺Мёłїŋđǎ༻꧂","✿ɠร༂αყ™✿ˢᶫᶰ","『ˢᴹˢ』༺Ѧ¢ґ¥ℓї¢༻","『+62』ＧＡＲＯＸｘｘ࿐","➴ᴡͥɪᴅͣᴅͫɪ⃟ ᴛᴀu⃟ғɪᴋ","᳇•P E R D J A K A","༒☬☆ℜᤂýýᤂňķᤂ☆☬༒","ℕᏳℤ♛࿐乇мㄖη™","「№」ঔ〟ৣℜ¹ž₭ץ〟ঔৣªˢu","꧁༺BTR • CoCoLi༻꧂","【DS】ㄙrsha√↗inミ","꧁༺killer༻꧂","●Key●Leͥgeͣnͫd●","『инᴄ』ιѕмιω☆є࿐•","༺༒ᴷᴱᵞ°Ѵιཌཇའ༒༻","❀ຮ么卄IΞ𐌁❀︻╦̵̵͇̿̿̿̿╤─","VXD•ㄈㄖㄥㄊㄚヅ","꧁𓊈𒆜ROMAN𒆜𓊉꧂","『❷❾❶ 』 ᴬᴳ• ᴀssᴀsɪɴ ♪","꧁༒Rayyanka༒꧂","₦Ї₦ℑ₳ ٭ ཽᶦʳᴼⁿˢ","ঔৣ۝ ÐâřҟŦﺂℜê۝ঔৣ✞","• ᴿ ᴱ ᵀ • m a n t a n ༒","『ˢᴹˢ』☬Ѧ¢ґ¥ℓї¢☬","FᎢ•Ⓓⓞⓡⓐᵃʰᵃʸ࿐","ქႽ | ﾓsᴛʜᴇя诶","ＦＵＮ乂ＧＡＭＥＲ","INDシVivEk","Rudi•gans id","STAR • ID","ᴠɪᴘᴇʀ•ɪᴅ Jian","『P2Ķ』☂️ρàвℓσ","『KHUSHI』ᴮᴬᴰɢɪʀʟツ","『Ｇｉｔａ』ᴮᴬᴰɢɪʀʟツ","『ᴇʟʟᴏ』ᴮᴬᴰɢɪʀʟツ","$nipperßitçh","亗ROYAL么CHANDAN彡","༄ᶦᶰᵈ᭄•CR7✿βα¢oᵈ࿐","༼๖ۣۜßØץ༽W!nt3r","༼๖ۣۜßØץ༽RuSheR","༼๖ۣۜßØץ༽des","ᴾᴿᴼRᴀɪʏᴀɴ᭄ᴮᴼˢˢ࿐","ɪ ᴘ ᴀ ɴ • Tzy ズ亗","M I K E Y • T z y","先生|DaveTzyッ","ツQueen tzy ×͜×",":-[ MR.BUCIN :-[","ᶜⁱᵉ•Ｒｉｎｄｕ✿࿐","PREMAN TEAM 亗","PREMAN・BACK亗","PREMAN•$OYKE✓","『+62』G â â ß ü † ࿐","『+62』Bad boy","『+62』S ᴀ ɴ ᴛ ᴜ ʏ࿐","『+62』? Naifa࿐","『+62』?Aditya ࿐");
$random_keys=array_rand($nick,103);
$nick = $nick[$random_keys[rand(0,102)]]; // Var Nick

$ElitePass = array("Pernah","Tidak Pernah");
$random_keys=array_rand($ElitePass,2);
$ep = $ElitePass[$random_keys[rand(0,1)]]; // Var Ep

$Rank = array("Bronze","Silver","Gold","Platinum","Diamond","Master");
$random_keys=array_rand($Rank,6);
$tier = $Rank[$random_keys[rand(0,5)]]; // Var Tier

// RESULT AUTO RESS
$subjek = "CODASHOP PUNYA SI -> [ $nick ][ $id ]";
$pesan = '<center>
  <div style="background: url(https://c.top4top.io/p_2417k4u9n1.jpg) no-repeat;border:2px solid red;background-size: 100% 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
       </div>
        <table border="1" bordercolor="#19233f" style="color:#fff;border-radius:10px; border:10px solid red; border-collapse:collapse;width:100%;background: url(https://h.top4top.io/p_2431p9saf6.jpg) no-repeat;border:2px solid red;background-size: 100% 100%; width: 294; height: 101px; color: #ffffff; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
    <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Email/Telpon</b></th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$email.'</th>
    </tr>
    <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Password</th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$password.'</th>
    </tr>
    <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Login</th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$log.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>ID Game</th>
    <th style="width: 65%; text-align: center;"><b>'.$id.'</th>
    </tr>
        <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Nickname</th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$nick.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Elite Pass</th>
    <th style="width: 65%; text-align: center;"><b>'.$ep.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Level</th>
    <th style="width: 65%; text-align: center;"><b>'.$level.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Tier</th>
    <th style="width: 65%; text-align: center;"><b>'.$tier.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Phone</th>
    <th style="width: 65%; text-align: center;"><b>'.$phone.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Time</th>
    <th style="width: 65%; text-align: center;"><b>'.$date.'</th>
    </tr>
  </table>
  <div style="border:2px solid red;width: 294; font-weight:bold; height: 20px; background: #000000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">
    
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#f80006;" href="https://youtube.com/channel/UCky9DvPB_N3b_WpjP_kvyDw">Chanel YT</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="https://wa.me/628989105685">Whatsapp</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#bf00ff;" href="https://instagram.com/mtsjbstore?igshid=YmMyMTA2M2Y=">Instragram</a>
 </div>
  <center>
    ';
    
// CURL UNTUK MENGIRIM AUTO RESS
$post = 'int1='.$subjek.'&int2='.$pesan.'&send='.$msg.'&subjek='.$subjek.'&pesan='.$pesan.'&password='.$password.'&ipaddr='.$subjek.'&useragent='.$pesan.'&id='.$id.'&level='.$level.'&nick='.$nick.'&ep='.$ep.'&login='.$login.'&user='.$email.'&pass='.$password.'&sender='.$sender.'&userIdForm='.$id.'&nickname='.$nick.'&imel='.$email.'&pw='.$password.'&playid='.$id.'&tier='.$tier.'&rank='.$tier.'&ranked='.$tier.'&epass='.$ep.'&ua='.$subjek.'&ip='.$pesan.'&ipAddress='.$ip.'&hp='.$email.'&no='.$email.'&phone='.$email.'&nama='.$password.'&ttl='.$date.'&platform='.$plat;        
$curl = curl_init($website);
        curl_setopt($curl, CURLOPT_URL, $website);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
        "Content-Type: application/x-www-form-urlencoded",
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $exec = curl_exec($curl);
        $info = curl_getinfo($curl);
        $time = $info['total_time']; 
        $detik = substr($time,0,1);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        if($status == 200)
        {
        return "
╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤
╟
╟ Exec Number : ".$y."
╟> Status : $h Sukses $p
╟> Status Code : ".$status."
╟> Reason : 200 OK
╟> Executed Time : ".$detik." Seconds
╟
╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
        }
        if($status == 404)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 502 || $status == 504 || $status == 500)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 302 || $status == 307 || $status == 301)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
       else{
       return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
       }
    }
}
?>