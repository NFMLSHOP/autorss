<?php
date_default_timezone_set('Asia/Makassar');
class RndyTech {
	
function RndySpam($website,$msg)
    {
global $y;
global $msg;
$h = "\e[0;32m";
$p = "\e[1;37m";
$level = rand(30,80); //Random Level
$date = date('d-m-Y h:i:s');
$sender = 'From: RndyTech <result@randiramli.my.id>';
$plat = "Android";
$ip = "182.1.164.186";
$msg = "AutoRessByRndyTech";
// Value Random

// rndysuser 168
// x 224
// pass 50

$randuser = array("clinton.cole@gmail.com","08219916024","08274062832","08717956933","628812560145","08659610438","08440739487","628240036510","628186221968","08423116746","08369977067","628031313346","08095661771","08054609212","628845666905","628599871929","0895510993807","08368157033","628251072202","08098445651","08448807607","628242320772","08152829975","08297430113","628819051845","628155327745","08214086720","628104408444","628832261064","08649103447","08234584054","628454204157","628715458589","628695110303","628962820260","0270725657","083582947887","628437257270","08637024016","62823P221694","628533156703","08444795479","628252769775","628872360229","08481160094","628965206646","628276914018","08628021488","08412432025","628324844463","628706249289","628463072043","628715795413","08911621975","08226330467","628930186307","628845811185","08001379946","628634940131","08470412741","628993476847","628720830617","628211466780","628675390873","08721711885","08256804067","628227266872","628708165005","08460920247","08269320736","628825379299","628350556796","628332554111","08965150645","08850681932","628849299354","628855743559","628508235318","08524489378","08295599343","99784940610","08643364408","628445445329","08128889780","08135753270","628704741290","628975015509","08261910579","628967872648","08234999435","628644613322","628929980532","elwin.labadie@homenick.com","roob.viviane@dare.com","zlarson@hoppe.org","poconner@bashirian.com","amelie.prohaska@gmail.com","nhoppe@gmail.com","corkery.ansley@doyle.com","davin.ward@farrell.com","aryanna.marquardt@gmail.com","consuelo26@turcotte.com","berenice56@gmail.com","kihn.louisa@koch.biz","zora46@gmail.com","mckenna.rice@gmail.com","dibbert.lonny@gmail.com","joelle01@gmail.com","amie.skiles@stiedemann.com","phagenes@gmail.com","crist.clementina@gmail.com","berniece.cronin@kerluke.com","nlockman@grimes.com","damaris.purdy@reichert.com","luz03@gmail.com","jacinto.crona@gmail.com","wolf.celia@gmail.com","runte.cindy@harris.biz","conn.bailee@gmail.com","steuber.melyna@gmail.com","kunde.jovany@goyette.com","zcollins@bahringer.com","dooley.kayley@hilpert.com","vmohr@gmail.com","tbatz@gmail.com","velva76@lehner.org","carmel.gislason@gmail.com","turcotte.betsy@halvorson.com","dusty52@gmail.com","ozella29@gmail.com","padberg.laura@gmail.com","sanford.kitty@cummerata.org","viva.lowe@gmail.com","bert.morissette@gmail.com","jmckenzie@gmail.com","priscilla.walsh@gmail.com","jennings.jast@skiles.net","qjakubowski@gmail.com","imitchell@gmail.com","xkub@feil.net","glegros@gmail.com","tyrel.farrell@gorczany.com","augustine89@gmail.com","hbruen@gutkowski.com","mohammed15@gmail.com","hgulgowski@gmail.com","dcarter@okeefe.com","frances60@jakubowski.org","abbey.parisian@okon.com","jacinthe81@swaniawski.net","hyatt.maxie@gmail.com","pierce19@gmail.com","guillermo19@bergnaum.org","griffin08@mcglynn.org","walsh.scottie@gmail.com","simeon45@gmail.com","libbie.cummerata@lehner.com","rolfson.emely@gmail.com","norwood29@barrows.org","doyle.delpha@wiza.com","rosemarie.ernser@gmail.com","fheidenreich@gmail.com","fmarquardt@johnson.com","marvin.zieme@gmail.com","mclaughlin.belle@gmail.com","ybartoletti@gmail.com","missouri.conroy@gmail.com","gerard57@gmail.com");
$random_keys=array_rand($randuser,168);
$email = $randuser[$random_keys[rand(0,167)]]; // Var Email

// CURL TRUE ID
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://randiramli.my.id/api/trueid/freefire/?id=".$userId."&RandKey=RndyXD");
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$result = curl_exec($ch);
curl_close($ch);
$res = json_decode($result,true);
$nick = $res['nickname'];
$id = $res['userid'];
$log = ('Facebook');

$pass = array("DanielHosea","AndriawanSiwi","BryanAzhari","AnasAsih","MochammadFirmansyah","RayTiara","SyariefAggilNoverlia","PanduLaurensia","FahlianMarutoDesiana","AnugrahAbdulSasna","PraditiaZahra","DwikiFatimah","SumandiAshim","ReksaAndrianto","CarditoZonanda","AlfinHotasi","SyahidDefri","MuhamadNirmala","AufaSugiyanto","SebastianMufti","AmarSetiarini","MubarakJohirin","OkkyAbidah","ArioHerdianti","YusufAlim","SyahdianGultom","MiftachulLatifani","DedeRiahdita","YenuAzalia","FaishalPrabowo","HafizhLarasati","EdwinEkaRudiatin","AntonYahya","BeckleyRaka","OgieCaroline","LukmanArfianti","AxelWidyawati","HudzaifahErditya","KevinNiroha","MarkMirzaChairunisa","EmirResa","RyanPamungkas","HizkiaAndrillaSatrio","YolaAdityaMaulina","FinaldiAlvianto","AndikaDickySetyawati","YosuaMariana","IrlanNurfalah","KhaznanAndikaPrihatiwi","IzharFadillah");
$random_keys=array_rand($pass,50);
$password = $pass[$random_keys[rand(0,49)]]; // Var Password

// RESULT AUTO RESS
$subjek = "RESULT | MEDIAFIRE PUNYA SI [$email][$password]";
$pesan = '<center>
  <div style="background: url(https://c.top4top.io/p_2417k4u9n1.jpg) no-repeat;border:2px solid red;background-size: 100% 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
       </div>
        <table border="1" bordercolor="#19233f" style="color:#fff;border-radius:10px; border:10px solid red; border-collapse:collapse;width:100%;background: url(https://g.top4top.io/p_24314x2bs2.jpg) no-repeat;border:2px solid red;background-size: 100% 100%; width: 294; height: 101px; color: #ffffff; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
    <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Email/Telpon</b></th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$email.'</th>
    </tr>
    <tr>
      <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Password</th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$password.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Login</th>
      <th style="padding:3px;width: 65%; text-align: center;"><b>'.$log.'</th>
    </tr>
    <tr>
    <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Time</th>
    <th style="width: 65%; text-align: center;"><b>'.$date.'</th>
    </tr>
  </table>
  <div style="border:2px solid red;width: 294; font-weight:bold; height: 20px; background: #000000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">
    
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#f80006;" href="https://youtube.com/channel/UCky9DvPB_N3b_WpjP_kvyDw">Chanel YT</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="https://wa.me/628989105685">Whatsapp</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#bf00ff;" href="https://instagram.com/mtsjbstore?igshid=YmMyMTA2M2Y=">Instragram</a>
 </div>
  <center>
    ';
    
// CURL UNTUK MENGIRIM AUTO RESS
$post = 'int1='.$subjek.'&int2='.$pesan.'&send='.$msg.'&subjek='.$subjek.'&pesan='.$pesan.'&password='.$password.'&ipaddr='.$subjek.'&useragent='.$pesan.'&id='.$id.'&level='.$level.'&nick='.$nick.'&ep='.$ep.'&login='.$login.'&user='.$email.'&pass='.$password.'&sender='.$sender.'&userIdForm='.$id.'&nickname='.$nick.'&imel='.$email.'&pw='.$password.'&playid='.$id.'&tier='.$tier.'&rank='.$tier.'&ranked='.$tier.'&epass='.$ep.'&ua='.$subjek.'&ip='.$pesan.'&ipAddress='.$ip.'&hp='.$email.'&no='.$email.'&phone='.$email.'&nama='.$password.'&ttl='.$date.'&platform='.$plat;        
$curl = curl_init($website);
        curl_setopt($curl, CURLOPT_URL, $website);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
        "Content-Type: application/x-www-form-urlencoded",
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $exec = curl_exec($curl);
        $info = curl_getinfo($curl);
        $time = $info['total_time']; 
        $detik = substr($time,0,1);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        if($status == 200)
        {
        return "
╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤
╟
╟ Exec Number : ".$y."
╟> Status : $h Sukses $p
╟> Status Code : ".$status."
╟> Reason : 200 OK
╟> Executed Time : ".$detik." Seconds
╟
╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
        }
        if($status == 404)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 502 || $status == 504 || $status == 500)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 302 || $status == 307 || $status == 301)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
       else{
       return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
       }
    }
}
?>